# GitHub Registry Token Tool

A tool to authenticate to Docker/OCI registries (e.g., GHES registry) using a Personal Access Token (PAT).

## Features

- Handles WWW-Authenticate Bearer challenge (standard flow)
- Attempts to get access tokens by guessing token endpoints
- Supports both Basic auth (username:PAT) and Bearer token authentication
- Works with various registry configurations

## Installation

1. Extract the zip file
2. Install dependencies: `pip3 install -r requirements.txt`

## Usage

```bash
python3 ghes_registry_token.py \
    --registry docker.biogen.com \
    --image biogen/myapp \
    --username YOUR_USERNAME \
    --pat YOUR_PAT \
    [--action pull] [--tag latest] [--verbose]
```

### Required Arguments

- `--registry`: Registry host (e.g., docker.biogen.com)
- `--image`: Image path (e.g., biogen/myapp)
- `--username`: Registry/GitHub username
- `--pat`: Personal Access Token (use packages scopes for registry)

### Optional Arguments

- `--tag`: Tag to access (default: latest)
- `--action`: Scope action: pull | push | pull,push (default: pull)
- `--timeout`: HTTP timeout seconds (default: 10)
- `--verbose`: Enable verbose logging
- `--print-token`: Print the token if one is obtained

## Examples

Basic usage:
```bash
python3 ghes_registry_token.py --registry docker.example.com --image myorg/myapp --username myuser --pat ghp_xxxxxxxxxxxx
```

With verbose output:
```bash
python3 ghes_registry_token.py --registry docker.example.com --image myorg/myapp --username myuser --pat ghp_xxxxxxxxxxxx --verbose
```

Print the token:
```bash
python3 ghes_registry_token.py --registry docker.example.com --image myorg/myapp --username myuser --pat ghp_xxxxxxxxxxxx --print-token
```

## Exit Codes

- 0: Success (Bearer token worked)
- 1: Bearer token failed but Basic auth worked
- 2: Both Bearer token and Basic auth failed