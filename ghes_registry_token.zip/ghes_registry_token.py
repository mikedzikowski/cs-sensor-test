#!/usr/bin/env python3
"""
Authenticate to a Docker/OCI registry (e.g., GHES registry) using a PAT and:
  1) Handle the WWW-Authenticate Bearer challenge (standard flow).
  2) If no challenge, attempt to get an access token by guessing token endpoints,
     trying both Basic (username:PAT) and a Bearer token built from base64(username:PAT).

Usage:
  python ghes_registry_token.py \
      --registry docker.biogen.com \
      --image biogen/myapp \
      --username USERNAME \
      --pat YOUR_PAT \
      [--action pull] [--tag latest] [--verbose]
"""
import argparse
import base64
import json
import re
import sys
from typing import Dict, Optional, Tuple
import requests

DEFAULT_ACCEPT = (
    "application/vnd.oci.image.manifest.v1+json, "
    "application/vnd.docker.distribution.manifest.v2+json, "
    "application/vnd.docker.distribution.manifest.v1+json"
)

def b64(s: str) -> str:
    return base64.b64encode(s.encode("utf-8")).decode("ascii")

def probe_registry(registry: str, image: str, tag: str, timeout: float = 10.0) -> Tuple[int, Dict[str, str]]:
    """Do an unauthenticated probe to trigger 401 + WWW-Authenticate (if supported)."""
    url = f"https://{registry}/v2/{image}/manifests/{tag}"
    resp = requests.get(url, headers={"Accept": DEFAULT_ACCEPT}, timeout=timeout)
    # Collect case-insensitive headers into a plain dict
    hdrs = {k.title(): v for k, v in resp.headers.items()}
    return resp.status_code, hdrs

def parse_www_authenticate(www: str) -> Dict[str, str]:
    """
    Parse a WWW-Authenticate header for Bearer params like:
      Bearer realm="https://.../token",service="docker.biogen.com",scope="repository:ns/name:pull"
    Returns dict with keys: scheme, realm, service, scope (missing keys may be absent).
    """
    out = {"scheme": "", "realm": "", "service": "", "scope": ""}
    if not www:
        return out
    # Split off scheme
    m = re.match(r'^\s*([A-Za-z]+)\s+(.*)$', www)
    if not m:
        return out
    out["scheme"] = m.group(1)
    params = m.group(2)

    # Extract key="value" pairs
    for key in ("realm", "service", "scope"):
        mm = re.search(rf'{key}\s*=\s*"([^"]+)"', params)
        if mm:
            out[key] = mm.group(1)
    return out

def token_via_bearer_challenge(realm: str, service: str, scope: str,
                               username: str, pat: str,
                               timeout: float = 10.0, verbose: bool = False) -> Optional[str]:
    """Exchange username:PAT for a registry Bearer token using the challenge-provided realm/service/scope."""
    if not scope:
        # Construct a default scope if server didn’t provide one (rare, but safe fallback)
        # Caller should pass a best-effort scope like repository:ns/name:pull
        pass
    url = f"{realm}?service={service}"
    if scope:
        url += f"&scope={scope}"
    if verbose:
        print(f"[challenge] GET {url}")

    resp = requests.get(
        url,
        headers={"Accept": "application/json"},
        auth=(username, pat),
        timeout=timeout
    )
    if verbose:
        print(f"[challenge] status={resp.status_code} body={resp.text[:300]}...")
    if resp.ok:
        data = resp.json()
        return data.get("token") or data.get("access_token")
    return None

def guess_token_endpoints(registry: str) -> Tuple[str, ...]:
    """
    Common token endpoints some registries expose (order matters).
    We’ll try each until one returns a token-like payload.
    """
    return (
        f"https://{registry}/token",
        f"https://{registry}/oauth2/token",
        f"https://{registry}/oauth/token",
        # Some reverse proxies mount at /v2/token
        f"https://{registry}/v2/token",
    )

def try_guess_token(registry: str, scope: str, username: str, pat: str,
                    timeout: float = 10.0, verbose: bool = False) -> Optional[str]:
    """
    Attempt to fetch a token without a WWW-Authenticate challenge:
     1) Try GET with Basic auth (username:PAT).
     2) Try GET with Bearer base64(username:PAT) as requested.
    """
    endpoints = guess_token_endpoints(registry)
    basic = "Basic " + b64(f"{username}:{pat}")
    bearer_from_basic = "Bearer " + b64(f"{username}:{pat}")

    for ep in endpoints:
        for auth_header in (basic, bearer_from_basic):
            url = f"{ep}?service={registry}&scope={scope}"
            if verbose:
                print(f"[guess] GET {url}  Authorization: {auth_header.split()[0]} …")
            resp = requests.get(
                url,
                headers={
                    "Accept": "application/json",
                    "Authorization": auth_header
                },
                timeout=timeout
            )
            if verbose:
                print(f"[guess] status={resp.status_code} body={resp.text[:300]}...")
            if resp.ok:
                try:
                    data = resp.json()
                except json.JSONDecodeError:
                    continue
                token = data.get("token") or data.get("access_token")
                if token:
                    return token
    return None

def fetch_manifest_with_token(registry: str, image: str, tag: str, token: str,
                              timeout: float = 10.0, verbose: bool = False) -> bool:
    url = f"https://{registry}/v2/{image}/manifests/{tag}"
    if verbose:
        print(f"[fetch] GET {url}  (Bearer token...)")
    resp = requests.get(
        url,
        headers={
            "Accept": DEFAULT_ACCEPT,
            "Authorization": f"Bearer {token}",
        },
        timeout=timeout
    )
    if verbose:
        print(f"[fetch] status={resp.status_code}")
    return resp.ok

def fetch_manifest_with_basic(registry: str, image: str, tag: str,
                              username: str, pat: str,
                              timeout: float = 10.0, verbose: bool = False) -> bool:
    """Last resort: some registries accept direct Basic auth for v2 endpoints."""
    url = f"https://{registry}/v2/{image}/manifests/{tag}"
    if verbose:
        print(f"[basic] GET {url}  (Basic username:PAT)")
    resp = requests.get(
        url,
        headers={"Accept": DEFAULT_ACCEPT},
        auth=(username, pat),
        timeout=timeout
    )
    if verbose:
        print(f"[basic] status={resp.status_code}")
    return resp.ok

def main():
    ap = argparse.ArgumentParser(description="Fetch a registry token (or manifest) using PAT with/without WWW-Authenticate.")
    ap.add_argument("--registry", required=True, help="Registry host, e.g. docker.biogen.com")
    ap.add_argument("--image", required=True, help="Image path, e.g. biogen/myapp")
    ap.add_argument("--tag", default="latest", help="Tag to access (default: latest)")
    ap.add_argument("--username", required=True, help="Registry/GitHub username")
    ap.add_argument("--pat", required=True, help="Personal Access Token (use packages scopes for registry)")
    ap.add_argument("--action", default="pull", help="Scope action: pull | push | pull,push (default: pull)")
    ap.add_argument("--timeout", type=float, default=10.0, help="HTTP timeout seconds (default: 10)")
    ap.add_argument("--verbose", action="store_true", help="Verbose logging")
    ap.add_argument("--print-token", action="store_true", help="Print the token if one is obtained")
    args = ap.parse_args()

    scope = f"repository:{args.image}:{args.action}"

    # Step 1: Probe for Bearer challenge
    status, headers = probe_registry(args.registry, args.image, args.tag, timeout=args.timeout)
    www = headers.get("Www-Authenticate", "")
    if args.verbose:
        print(f"[probe] status={status} WWW-Authenticate={www!r}")

    token: Optional[str] = None

    # If we got a Bearer challenge, do the standard flow
    parsed = parse_www_authenticate(www)
    if parsed.get("scheme", "").lower() == "bearer" and parsed.get("realm"):
        realm = parsed["realm"]
        service = parsed.get("service") or args.registry
        challenge_scope = parsed.get("scope") or scope
        if args.verbose:
            print(f"[challenge] realm={realm} service={service} scope={challenge_scope}")
        token = token_via_bearer_challenge(
            realm=realm,
            service=service,
            scope=challenge_scope,
            username=args.username,
            pat=args.pat,
            timeout=args.timeout,
            verbose=args.verbose
        )

    # If no challenge or failed to get token, try “no-challenge” guesses
    if not token:
        if args.verbose:
            print("[fallback] No usable Bearer challenge or token exchange failed; trying guess endpoints…")
        token = try_guess_token(
            registry=args.registry,
            scope=scope,
            username=args.username,
            pat=args.pat,
            timeout=args.timeout,
            verbose=args.verbose
        )

    if token:
        if args.print_token:
            print(token)
        # Prove it works by fetching the manifest with Bearer
        ok = fetch_manifest_with_token(
            args.registry, args.image, args.tag, token,
            timeout=args.timeout, verbose=args.verbose
        )
        print("Bearer manifest fetch:", "OK" if ok else "FAILED")
        sys.exit(0 if ok else 1)

    # Final fallback: try direct Basic auth (some registries allow it)
    if args.verbose:
        print("[final] Trying direct Basic auth to the manifest endpoint…")
    ok = fetch_manifest_with_basic(
        args.registry, args.image, args.tag,
        args.username, args.pat,
        timeout=args.timeout, verbose=args.verbose
    )
    print("Basic manifest fetch:", "OK" if ok else "FAILED")
    # Exit non-zero if both token and basic failed
    sys.exit(0 if ok else 2)

if __name__ == "__main__":
    main()